import pygame
import sys
import json
import random
import time
from pathlib import Path

pygame.mixer.pre_init(44100, -16, 2, 512)

# ---------------------- Configuration et constantes ----------------------
APP_NAME = "Minesweeper Solver - NSI"
ASSETS_DIR = Path("assets")
DATA_FILE = Path("data.json")

DIFFICULTIES = {
    "Débutant": (9, 9, 10),
    "Intermédiaire": (16, 16, 40),
    "Expert": (30, 16, 99),
}

DEFAULT_SETTINGS = {
    "theme": "sombre", 
    "music": True,
    "difficulty": "Débutant",
    "records": {"Débutant": None, "Intermédiaire": None, "Expert": None}
}

CELL_SIZE = 30
PADDING = 20
MENU_WIDTH = 600
MENU_HEIGHT = 480
FPS = 60

THEMES = {
    "sombre": {
        "bg": (30, 30, 30),
        "panel": (45, 45, 45),
        "text": (230, 230, 230),
        "cell_closed": (70, 70, 70),
        "cell_open": (160, 160, 160),
        "flag": (220, 50, 50),
        "mine": (0, 0, 0),
        "accent": (70, 130, 180)
    },
    "clair": {
        "bg": (240, 240, 240),
        "panel": (255, 255, 255),
        "text": (20, 20, 20),
        "cell_closed": (200, 200, 200),
        "cell_open": (230, 230, 230),
        "flag": (200, 40, 40),
        "mine": (0, 0, 0),
        "accent": (0, 100, 180)
    }
}

# ---------------------- Utilitaires ----------------------

def load_data():
    if DATA_FILE.exists():
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    save_data(DEFAULT_SETTINGS)
    return DEFAULT_SETTINGS.copy()

def save_data(data):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print("Erreur sauvegarde :", e)

# ---------------------- Logique du jeu ----------------------
class Cell:
    def __init__(self):
        self.is_mine = False
        self.opened = False
        self.flagged = False
        self.adj = 0

class Board:
    def __init__(self, cols, rows, mines):
        self.cols = cols
        self.rows = rows
        self.total_mines = mines
        self.grid = [[Cell() for _ in range(rows)] for _ in range(cols)]
        self.mines_placed = False
        self.opened_count = 0
        self.game_over = False
        self.victory = False

    def in_bounds(self, x, y):
        return 0 <= x < self.cols and 0 <= y < self.rows

    def neighbors(self, x, y):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx == 0 and dy == 0: continue
                nx, ny = x + dx, y + dy
                if self.in_bounds(nx, ny):
                    yield nx, ny

    def place_mines(self, safe_x, safe_y):
        positions = [(x, y) for x in range(self.cols) for y in range(self.rows) if not (x == safe_x and y == safe_y)]
        random.shuffle(positions)
        for i in range(self.total_mines):
            x, y = positions[i]
            self.grid[x][y].is_mine = True
        
        for x in range(self.cols):
            for y in range(self.rows):
                if self.grid[x][y].is_mine: continue
                self.grid[x][y].adj = sum(1 for nx, ny in self.neighbors(x, y) if self.grid[nx][ny].is_mine)
        self.mines_placed = True

    def open_cell(self, x, y):
        if not self.in_bounds(x, y): return
        cell = self.grid[x][y]
        if cell.opened or cell.flagged: return
        cell.opened = True
        self.opened_count += 1
        if cell.is_mine:
            self.game_over = True
            return
        if cell.adj == 0:
            for nx, ny in self.neighbors(x, y):
                self.open_cell(nx, ny)
        if self.opened_count == self.cols * self.rows - self.total_mines:
            self.victory = True
            self.game_over = True

    def toggle_flag(self, x, y):
        if not self.in_bounds(x, y): return
        cell = self.grid[x][y]
        if not cell.opened:
            cell.flagged = not cell.flagged

    def count_flags(self):
        return sum(1 for x in range(self.cols) for y in range(self.rows) if self.grid[x][y].flagged)

# ---------------------- Le Solveur IA ----------------------

class Solver:
    def __init__(self, board):
        self.board = board

    def get_hidden_neighbors(self, x, y):
        return [(nx, ny) for nx, ny in self.board.neighbors(x, y) if not self.board.grid[nx][ny].opened]

    def get_flagged_neighbors(self, x, y):
        return [(nx, ny) for nx, ny in self.board.neighbors(x, y) if self.board.grid[nx][ny].flagged]

    def logic_step(self):
        """Applique les stratégies 1 et 2. Retourne True si une action est faite."""
        changed = False
        opened_cells = [(x, y) for x in range(self.board.cols) for y in range(self.board.rows) 
                        if self.board.grid[x][y].opened and self.board.grid[x][y].adj > 0]

        # STRATÉGIE 1 : Analyse Déterministe Locale
        for x, y in opened_cells:
            cell = self.board.grid[x][y]
            hidden = self.get_hidden_neighbors(x, y)
            flags = self.get_flagged_neighbors(x, y)

            # Règle : Toutes les cases restantes sont des mines
            if len(hidden) == cell.adj and len(flags) < cell.adj:
                for hx, hy in hidden:
                    if not self.board.grid[hx][hy].flagged:
                        self.board.toggle_flag(hx, hy)
                        changed = True

            # Règle : Toutes les mines sont trouvées, on ouvre le reste
            if len(flags) == cell.adj and len(hidden) > len(flags):
                for hx, hy in hidden:
                    if not self.board.grid[hx][hy].flagged:
                        self.board.open_cell(hx, hy)
                        changed = True
        
        if changed: return True

        # STRATÉGIE 2 : Inférence par Ensembles
        for x, y in opened_cells:
            hidden_A = set(self.get_hidden_neighbors(x, y))
            mines_needed_A = self.board.grid[x][y].adj - len(self.get_flagged_neighbors(x, y))
            if mines_needed_A <= 0: continue

            for nx, ny in self.board.neighbors(x, y):
                if self.board.grid[nx][ny].opened and (nx, ny) != (x, y):
                    hidden_B = set(self.get_hidden_neighbors(nx, ny))
                    mines_needed_B = self.board.grid[nx][ny].adj - len(self.get_flagged_neighbors(nx, ny))

                    if hidden_A.issubset(hidden_B) and hidden_A != hidden_B:
                        diff = hidden_B - hidden_A
                        if mines_needed_A == mines_needed_B:
                            for dx, dy in diff:
                                if not self.board.grid[dx][dy].flagged and not self.board.grid[dx][dy].opened:
                                    self.board.open_cell(dx, dy)
                                    changed = True
                        elif mines_needed_B - mines_needed_A == len(diff):
                            for dx, dy in diff:
                                if not self.board.grid[dx][dy].flagged:
                                    self.board.toggle_flag(dx, dy)
                                    changed = True
        return changed

# ---------------------- Interface graphique ----------------------

class Button:
    def __init__(self, rect, text, font, action=None):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.font = font
        self.action = action

    def draw(self, surf, colors):
        pygame.draw.rect(surf, colors["panel"], self.rect, border_radius=10)
        txt = self.font.render(self.text, True, colors["text"])
        surf.blit(txt, txt.get_rect(center=self.rect.center))

    def is_hover(self, pos):
        return self.rect.collidepoint(pos)

class GameApp:
    def __init__(self):
        pygame.init()
        pygame.mixer.init()
        pygame.display.set_caption(APP_NAME)
        self.data = load_data()
        self.set_theme(self.data.get("theme", "sombre"))
        self.music_on = self.data.get("music", True)
        self.difficulty = self.data.get("difficulty", "Débutant")
        self.reset_board_for_difficulty()
        
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 24)
        self.large_font = pygame.font.SysFont(None, 36)
        self.state = 'menu'
        self.message = ''
        self.message_time = 0
        self.current_music = None
        self.play_music_for_state()
        self.game_start_time = None
        self.elapsed_time = 0

    def set_theme(self, theme_name):
        self.theme = theme_name if theme_name in THEMES else 'sombre'
        self.colors = THEMES[self.theme]

    def play_music_for_state(self):
        if not self.music_on:
            pygame.mixer.music.stop()
            return
        path = str(ASSETS_DIR / ('menu_music.mp3' if self.state == 'menu' else 'game_music.mp3'))
        if Path(path).exists() and self.current_music != path:
            try:
                pygame.mixer.music.load(path)
                pygame.mixer.music.play(-1)
                self.current_music = path
            except: pass

    def reset_board_for_difficulty(self):
        cols, rows, mines = DIFFICULTIES[self.difficulty]
        self.board = Board(cols, rows, mines)
        self.solver = Solver(self.board)
        width = max(MENU_WIDTH, cols * CELL_SIZE + 2 * PADDING)
        height = rows * CELL_SIZE + 140
        self.screen = pygame.display.set_mode((width, height))

    def show_message(self, text, duration=2.0):
        self.message = text
        self.message_time = time.time() + duration

    def save_settings(self):
        self.data.update({"theme": self.theme, "music": self.music_on, "difficulty": self.difficulty})
        save_data(self.data)

    def update_record_if_needed(self, seconds):
        records = self.data.get('records', {})
        rec = records.get(self.difficulty)
        if rec is None or seconds < rec:
            records[self.difficulty] = seconds
            self.data['records'] = records
            save_data(self.data)
            return True
        return False

    def draw_menu(self):
        self.screen.fill(self.colors['bg'])
        title = self.large_font.render('Minesweeper Solver', True, self.colors['accent'])
        self.screen.blit(title, (PADDING, PADDING))
        rec = self.data.get('records', {}).get(self.difficulty)
        rec_text = f"Record ({self.difficulty}) : {int(rec)}s" if rec else f"Record ({self.difficulty}) : --"
        self.screen.blit(self.font.render(rec_text, True, self.colors['text']), (PADDING, PADDING + 50))

        btn_w, btn_h = 220, 48
        cx = self.screen.get_width() // 2 - btn_w // 2
        self.buttons = [
            Button((cx, 140, btn_w, btn_h), "Jouer", self.large_font, self.start_game),
            Button((cx, 200, btn_w, btn_h), "Paramètres", self.large_font, lambda: self.state_switch('settings')),
            Button((cx, 260, btn_w, btn_h), "Tutoriel", self.large_font, lambda: self.state_switch('tutorial')),
            Button((cx, 320, btn_w, btn_h), "Quitter", self.large_font, self.quit)
        ]
        for b in self.buttons: b.draw(self.screen, self.colors)

    def state_switch(self, new_state):
        self.state = new_state
        self.play_music_for_state()

    def start_game(self):
        self.reset_board_for_difficulty()
        self.game_start_time = None
        self.elapsed_time = 0
        self.state = 'playing'
        self.play_music_for_state()

    def quit(self):
        self.save_settings()
        pygame.quit()
        sys.exit()

    def draw_settings(self):
        self.screen.fill(self.colors['bg'])
        y = PADDING + 60
        self.buttons = [
            Button((self.screen.get_width()-180, y-8, 140, 36), 'Thème', self.font, self.toggle_theme),
            Button((self.screen.get_width()-180, y+32, 140, 36), 'Musique', self.font, self.toggle_music),
            Button((self.screen.get_width()-180, y+72, 140, 36), 'Difficulté', self.font, self.cycle_diff),
            Button((PADDING, self.screen.get_height()-70, 120, 44), 'Retour', self.font, lambda: self.state_switch('menu'))
        ]
        self.screen.blit(self.font.render(f"Thème : {self.theme}", True, self.colors['text']), (PADDING, y))
        self.screen.blit(self.font.render(f"Musique : {'ON' if self.music_on else 'OFF'}", True, self.colors['text']), (PADDING, y+40))
        self.screen.blit(self.font.render(f"Difficulté : {self.difficulty}", True, self.colors['text']), (PADDING, y+80))
        for b in self.buttons: b.draw(self.screen, self.colors)

    def toggle_theme(self):
        self.theme = 'clair' if self.theme == 'sombre' else 'sombre'
        self.set_theme(self.theme)
        
    def toggle_music(self):
        self.music_on = not self.music_on
        self.play_music_for_state()

    def cycle_diff(self):
        keys = list(DIFFICULTIES.keys())
        self.difficulty = keys[(keys.index(self.difficulty) + 1) % len(keys)]
        self.reset_board_for_difficulty()

    def draw_tutorial(self):
        self.screen.fill(self.colors['bg'])
        y = 100
        lines = ["Clic Gauche : Ouvrir", "Clic Droit : Drapeau", "Touche S : Lancer l'IA Solveur", "Touche R : Recommencer"]
        for l in lines:
            self.screen.blit(self.font.render(l, True, self.colors['text']), (PADDING, y))
            y += 40
        b = Button((PADDING, self.screen.get_height()-70, 120, 44), 'Retour', self.font, lambda: self.state_switch('menu'))
        b.draw(self.screen, self.colors)
        self.buttons = [b]

    def draw_game(self):
        self.screen.fill(self.colors['bg'])
        pygame.draw.rect(self.screen, self.colors['panel'], (0, 0, self.screen.get_width(), 100))
        
        mines_left = self.board.total_mines - self.board.count_flags()
        self.screen.blit(self.large_font.render(f'Mines : {mines_left}', True, self.colors['text']), (PADDING, 20))
        
        if self.game_start_time and not self.board.game_over:
            self.elapsed_time = int(time.time() - self.game_start_time)
        self.screen.blit(self.large_font.render(f'Temps : {self.elapsed_time}s', True, self.colors['text']), (200, 20))
        
        sett_btn = Button((self.screen.get_width()-140, 20, 120, 40), 'Menu', self.font, lambda: self.state_switch('menu'))
        sett_btn.draw(self.screen, self.colors)
        self.buttons = [sett_btn]

        ox = (self.screen.get_width() - self.board.cols * CELL_SIZE) // 2
        oy = 110
        for x in range(self.board.cols):
            for y in range(self.board.rows):
                cell = self.board.grid[x][y]
                rect = pygame.Rect(ox + x * CELL_SIZE, oy + y * CELL_SIZE, CELL_SIZE, CELL_SIZE)
                if cell.opened:
                    pygame.draw.rect(self.screen, self.colors['cell_open'], rect)
                    if cell.is_mine: pygame.draw.circle(self.screen, self.colors['mine'], rect.center, 10)
                    elif cell.adj > 0:
                        txt = self.font.render(str(cell.adj), True, self.colors['text'])
                        self.screen.blit(txt, txt.get_rect(center=rect.center))
                else:
                    pygame.draw.rect(self.screen, self.colors['cell_closed'], rect)
                    if cell.flagged:
                        pygame.draw.polygon(self.screen, self.colors['flag'], [(rect.left+5, rect.bottom-5), (rect.left+5, rect.top+5), (rect.right-5, rect.centery)])
                pygame.draw.rect(self.screen, self.colors['bg'], rect, 1)

        if self.board.game_over:
            msg = 'VICTOIRE !' if self.board.victory else 'GAME OVER'
            txt = self.large_font.render(msg, True, self.colors['accent'])
            self.screen.blit(txt, txt.get_rect(center=(self.screen.get_width()//2, self.screen.get_height()//2)))

    def handle_game_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()
            ox, oy = (self.screen.get_width() - self.board.cols * CELL_SIZE) // 2, 110
            gx, gy = (mx - ox) // CELL_SIZE, (my - oy) // CELL_SIZE
            
            for b in self.buttons:
                if b.is_hover((mx, my)): b.action(); return

            if self.board.in_bounds(gx, gy) and not self.board.game_over:
                if event.button == 3: self.board.toggle_flag(gx, gy)
                elif event.button == 1:
                    if not self.board.mines_placed:
                        self.board.place_mines(gx, gy)
                        self.game_start_time = time.time()
                    self.board.open_cell(gx, gy)
                    if self.board.game_over and self.board.victory:
                        self.update_record_if_needed(int(time.time() - self.game_start_time))

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r: self.start_game()
            elif event.key == pygame.K_s and not self.board.game_over:
                # Si le jeu n'est pas lancé, l'IA clique au milieu
                if not self.board.mines_placed:
                    mid_x, mid_y = self.board.cols // 2, self.board.rows // 2
                    self.board.place_mines(mid_x, mid_y)
                    self.game_start_time = time.time()
                    self.board.open_cell(mid_x, mid_y)
                else:
                    if not self.solver.logic_step():
                        self.show_message("IA bloquée : hasard requis", 1.5)

    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: self.quit()
                if self.state == 'menu': self.handle_menu_event(event)
                elif self.state == 'settings': self.handle_settings_event(event)
                elif self.state == 'playing': self.handle_game_event(event)
                elif self.state == 'tutorial' and event.type == pygame.MOUSEBUTTONDOWN:
                    for b in self.buttons:
                        if b.is_hover(pygame.mouse.get_pos()): b.action()

            if self.state == 'menu': self.draw_menu()
            elif self.state == 'settings': self.draw_settings()
            elif self.state == 'tutorial': self.draw_tutorial()
            elif self.state == 'playing': self.draw_game()

            if self.message and time.time() < self.message_time:
                msg_surf = self.font.render(self.message, True, (255, 255, 0))
                self.screen.blit(msg_surf, (self.screen.get_width()//2 - msg_surf.get_width()//2, 110))
            
            pygame.display.flip()
            self.clock.tick(FPS)

    def handle_menu_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            for b in self.buttons:
                if b.is_hover(pygame.mouse.get_pos()): b.action()

    def handle_settings_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            for b in self.buttons:
                if b.is_hover(pygame.mouse.get_pos()): b.action()

if __name__ == '__main__':
    app = GameApp()
    app.run()