# Projet de Terminale : Démineur (Minesweeper)

Ce dépôt contient l'intégralité de notre projet de Terminale NSI : la réalisation d'un jeu du Démineur en Python avec interface graphique, gestion des paramètres, musique, chronomètre et enregistrement des records. Le projet a été réalisé sur plusieurs jours et nous a permis d'apprendre à utiliser différentes bibliothèques, à structurer un programme interactif et à résoudre de nombreuses problématiques techniques.

# Objectifs du projet

- Programmer un jeu complet du démineur en Python
- Utiliser une interface graphique (Pygame)
- Implémenter un menu principal + tutoriel + paramètres
- Ajouter une musique de fond (menu + jeu)
- Ajouter un chronomètre et sauvegarder le meilleur temps
- Assurer que le premier clic ne soit jamais une mine
- Proposer trois niveaux de difficulté (débutant, intermédiaire, expert)
- Permettre un thème clair ou sombre

# Outils et bibliothèques utilisées

**Python 3.10** 
Langage principal

**Pygame**
Utilisé pour :
- créer la fenêtre
- dessiner la grille et les boutons
- gérer les clics souris (gauche/droit)
- jouer la musique

**JSON**
Utilisé pour enregistrer :
- le meilleur temps
- les paramètres du joueur

**Documentation et sources consultées**
- Documentation officielle Pygame
- StackOverflow
- OpenClassrooms
- Forums Python francophones
- L' Intelligence Artificielle

# Problématiques rencontrées et solutions

Au cours du développement, nous avons rencontré plusieurs difficultés qui nous ont demandé des recherches, des tests et une amélioration progressive du code. Voici les principales problématiques résolues.

## 1. Le premier clic révélait une mine

### **Problème:**
Au début, les mines étaient générées dès la création de la grille. Il arrivait donc que le premier clic tombe sur une mine.

### **Recherches:**
Nous avons découvert, à travers plusieurs tutoriels et forums, que les implémentations modernes du démineur placent les mines seulement après le premier clic.

### **Solution:**
- la grille est initialement vide
- au premier clic, nous plaçons les mines en évitant la case cliquée
- nous calculons ensuite les mines adjacentes

Résultat : le premier clic n’est plus jamais une mine.

## 2. Impossible de différencier clic gauche et clic droit

### **Problème:**
Tous les clics déclenchaient la même action, ce qui empêchait de poser des drapeaux.

### **Recherches:**
La documentation Pygame nous a appris que :
- 'event.button == 1' correspond au clic gauche
- 'event.button == 3' correspond au clic droit

### **Solution:**
'''if event.type == pygame.MOUSEBUTTONDOWN:
    if event.button == 1:
        ouvrir_case()
    elif event.button == 3:
        poser_drapeau()'''

## 3. Le flood-fill ouvrait toute la grille

### **Problème:**
L’ouverture des cases vides provoquait un déploiement trop large dû à une récursion incorrecte.

### **Solution:**
Nous avons ajouté un test empêchant la récursion sur une case déjà ouverte.

## 4. Le chronomètre ne s’arrêtait pas correctement

### **Problème:**
Il continuait même après la victoire ou la défaite.

### **Solution:**
Le chronomètre démarre désormais au premier clic et s’arrête à la victoire.

## 5. Les records ne s’enregistraient pas entre deux sessions

### **Solution:**
Utilisation d’un fichier JSON pour sauvegarder et charger les meilleurs temps.

## 6. Nous n’arrivons pas à ajouter de la musique

### **Problème:**
Nous avons essayé d’ajouter une musique de fond dans le menu et en jeu, mais malgré plusieurs tentatives et modifications, la musique ne se lance pas.
Pygame ne charge pas ou ne lit pas les fichiers audio, et nous n’avons pas réussi à régler ce problème.

Il n’y a donc pas de solution dans l’état actuel du projet.

## 7. Séparer le code en plusieurs fichiers causait des erreurs d’import

### **Problème:**
Nous avons essayé de rendre le projet plus clair en séparant le code en plusieurs fichiers (par exemple un fichier pour la grille, un autre pour les menus, etc.).

### **Conséquence:**
À cause de ces erreurs répétées, nous avons été obligés de tout remettre dans un unique fichier **main.py** pour que le jeu fonctionne correctement.

# Interface utilisateur
- Boutons stylisés
- Thème clair ou sombre
- Menu principal, tutoriel, paramètres
- Indicateur du nombre de mines restantes
- Interface adaptée selon la difficulté

# Fonctionnalités du jeu
- Premier clic sécurisé
- Gestion des drapeaux avec clic droit
- Flood-fill optimisé
- Chronomètre fonctionnel
- Enregistrement du meilleur temps
- Trois niveaux de difficulté
- Deux musiques de fond (menu / jeu)
- Paramètres accessibles même en partie

# Conclusion
Ce projet nous a permis d'apprendre :
- la structure d’un jeu vidéo
- l’utilisation de Pygame
- la gestion des événements et de l’interface
- la manipulation de fichiers JSON
- la résolution de problèmes techniques concrets

Il nous a également donné une bonne expérience du débogage, de la recherche autonome et de la gestion de projet.

# Évolution du Projet (Trimestre 2) : Le "Minesweeper Solver"
Pour ce deuxième trimestre, l'objectif est de passer du statut de créateur de jeu à celui de concepteur d'IA. La mission est de théoriser et de développer un solveur capable d'analyser la grille et de prendre des décisions logiques pour gagner la partie sans intervention humaine.

## Théorisation de la stratégie de résolution
Résoudre un démineur n'est pas une question de chance, mais de logique pure. L'IA suit une hiérarchie de réflexion allant du plus simple au plus complexe.

## 1. L'Analyse de Voisinage (La logique directe)
C'est la base du raisonnement. L'IA examine chaque case numérotée et applique deux règles simples :

**La saturation des mines** : Si une case affiche "n" et qu'elle est entourée d'exactement n cases cachées, alors ces n cases sont forcément des mines (on pose des drapeaux).

**La zone sécurisée** : Si une case affiche "n" et qu'elle a déjà n drapeaux à son contact, alors toutes ses autres voisines masquées sont vides (on peut cliquer dessus).

## 2. L'Analyse de Frontières (La logique croisée)
Parfois, une case seule ne suffit pas. L'IA compare alors deux cases voisines pour voir si leurs besoins se recoupent.

**Le concept :** Si une case A a besoin d'une mine dans une zone qui est entièrement incluse dans la zone d'une case B, on peut déduire par soustraction les cases vides ou piégées de la case B.

Exemple (Le pattern 1-2) : C'est une situation classique où la position d'une mine pour un "1" aide à résoudre l'emplacement des deux mines pour un "2".

## 3. Résolution par système de contrainte (test d'erreur absurde)
Si les règles précédentes ne fonctionnent pas, l'IA utilise une méthode plus puissante : l'hypothèse.

L'IA choisit une case inconnue et suppose que c'est une mine.

Elle vérifie si cette supposition entraîne une erreur logique ailleurs sur la grille (par exemple, une case qui devrait avoir 2 mines se retrouve avec 3).

Si l'hypothèse crée une erreur, alors l'IA sait avec certitude que la case est vide.

## 4. La Gestion du Hasard (Le moindre risque)
Dans les situations de blocage total (50/50), l'IA abandonne la logique pour les probabilités.

Elle calcule le pourcentage de chances de tomber sur une mine pour chaque case de la frontière.

Elle choisit la case où le risque est mathématiquement le plus faible.
